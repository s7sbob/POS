// هذا الكود يمكن تشغيله في console المتصفح أو Node.js

// دالة رئيسية للآلة الحاسبة
function simpleCalculator() {
    console.log('🧮 آلة حاسبة بسيطة\n');
    
    // الأرقام للحساب
    const num1 = 10;
    const num2 = 5;
    
    console.log(`الرقم الأول: ${num1}`);
    console.log(`الرقم الثاني: ${num2}\n`);
    
    // عملية الجمع
    const addition = num1 + num2;
    console.log(`✅ الجمع: ${num1} + ${num2} = ${addition}`);
    
    // عملية الطرح
    const subtraction = num1 - num2;
    console.log(`✅ الطرح: ${num1} - ${num2} = ${subtraction}`);
    
    // عملية الضرب
    const multiplication = num1 * num2;
    console.log(`✅ الضرب: ${num1} × ${num2} = ${multiplication}`);
    
    // عملية القسمة
    const division = num1 / num2;
    console.log(`✅ القسمة: ${num1} ÷ ${num2} = ${division}`);
    
    // باقي القسمة
    const modulus = num1 % num2;
    console.log(`✅ باقي القسمة: ${num1} % ${num2} = ${modulus}`);
    
    // القوة
    const power = Math.pow(num1, 2);
    console.log(`✅ القوة: ${num1}² = ${power}`);
    
    // الجذر التربيعي
    const sqrt = Math.sqrt(num1);
    console.log(`✅ الجذر التربيعي: √${num1} = ${sqrt}`);
    
    console.log('\n================================');
}

// تشغيل الآلة الحاسبة
simpleCalculator();

// مثال على دالة حسابية عامة
function calc(num1, operator, num2) {
    // دالة واحدة تقبل أي عملية
    console.log('\n--- حساب جديد ---');
    
    let result;
    
    // التحقق من نوع العملية
    switch(operator) {
        case '+':
            result = num1 + num2;
            break;
        case '-':
            result = num1 - num2;
            break;
        case '*':
        case '×':
            result = num1 * num2;
            break;
        case '/':
        case '÷':
            if (num2 === 0) {
                console.log('❌ خطأ: القسمة على صفر!');
                return;
            }
            result = num1 / num2;
            break;
        case '%':
            result = num1 % num2;
            break;
        case '^':
            result = Math.pow(num1, num2);
            break;
        default:
            console.log('❌ عملية غير معروفة!');
            return;
    }
    
    console.log(`${num1} ${operator} ${num2} = ${result}`);
    return result;
}

// أمثلة على الاستخدام
console.log('\n--- أمثلة على الاستخدام ---');
calc(15, '+', 5);   // ناتج: 20
calc(15, '-', 5);   // ناتج: 10
calc(15, '*', 5);   // ناتج: 75
calc(15, '/', 5);   // ناتج: 3
calc(15, '%', 4);   // ناتج: 3
calc(2, '^', 8);    // ناتج: 256
