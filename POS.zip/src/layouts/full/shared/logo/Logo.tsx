import { FC } from 'react';
import { useSelector } from 'src/store/Store';
import { Link } from 'react-router';
import { styled } from '@mui/material';
import FoodifyLogo from 'src/assets/images/logos/foodify-logo.png';
import { AppState } from 'src/store/Store';

const Logo: FC = () => {
  const customizer = useSelector((state: AppState) => state.customizer);
  // Create a styled Link whose dimensions depend on the current layout settings.
  const LinkStyled = styled(Link)(() => ({
    height: customizer.TopbarHeight,
    width: customizer.isCollapse ? '40px' : '180px',
    overflow: 'hidden',
    display: 'block',
  }));

  // Regardless of theme (light/dark) or direction (LTR/RTL), always show the Foodify logo.
  return (
    <LinkStyled
      to="/"
      style={{ display: 'flex', alignItems: 'center' }}
    >
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img
        src={FoodifyLogo as string}
        alt="Foodify Logo"
        style={{ width: '100%', height: '100%', objectFit: 'contain' }}
      />
    </LinkStyled>
  );
};

export default Logo;
