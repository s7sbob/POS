// src/types/custom.d.ts
declare module 'arabic-reshaper';
declare module 'bidi-js';
