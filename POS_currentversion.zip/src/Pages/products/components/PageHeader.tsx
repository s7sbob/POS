// File: src/pages/products/components/PageHeader.tsx
import React from 'react';
import {
  Box,
  Typography,
  useMediaQuery,
  useTheme
} from '@mui/material';
import { useTranslation } from 'react-i18next';
import ImportExportManager from '../../components/ImportExportManager';
import { productsImportExportConfig } from '../../components/configs/importExportConfigs';
import { Product } from 'src/utils/api/pagesApi/productsApi';

interface Props {
  title: string; // ⭐ إضافة title كـ prop
  exportData: Product[];
  loading: boolean;
  showImport?: boolean; // ⭐ إضافة تحكم في الـ import/export
  showExport?: boolean;
}

const PageHeader: React.FC<Props> = ({ 
  title, 
  exportData, 
  loading, 
  showImport = true, 
  showExport = true 
}) => {
  const { t } = useTranslation();
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('md'));

  const config = {
    ...productsImportExportConfig,
    onExport: () => exportData.map(product => ({
      productName: product.name,
      groupName: product.group?.name || t('common.notSpecified'),
      productType: product.productType === 1 ? 'POS' : 
                   product.productType === 2 ? 'Material' : 
                   product.productType === 3 ? 'Addition' : 'Unknown',
      description: product.description,
      reorderLevel: product.reorderLevel,
      cost: product.cost,
      expirationDays: product.expirationDays,
      code: product.code,
      isActive: product.isActive ? t('common.active') : t('common.inactive')
    }))
  };

  return (
    <Box sx={{ mb: { xs: 2, sm: 3 } }}>
      <Box sx={{ 
        display: 'flex', 
        flexDirection: { xs: 'column', sm: 'row' },
        justifyContent: 'space-between', 
        alignItems: { xs: 'flex-start', sm: 'center' }, 
        mb: { xs: 1, sm: 2 },
        gap: { xs: 1, sm: 0 }
      }}>
        <Typography 
          variant={isMobile ? "h5" : "h4"} 
          component="h1"
          sx={{
            fontSize: { xs: '1.5rem', sm: '2rem', md: '2.125rem' },
            fontWeight: { xs: 600, sm: 500 }
          }}
        >
          {title} {/* ⭐ استخدام title المُمرر */}
        </Typography>
      </Box>

      <ImportExportManager
        config={config}
        data={exportData}
        loading={loading}
        compact={isMobile}
        showImport={showImport} // ⭐ تمرير الـ props
        showExport={showExport}
      />
    </Box>
  );
};

export default PageHeader;
